from rest_framework.views import APIView
from rest_framework.permissions import AllowAny
from .serializers import UserSerializer
from django.contrib.auth import authenticate, login
from rest_framework.response import Response
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import IsAuthenticated

class RegistrationView(APIView):
    permission_classes = [AllowAny]
    def post(self,request):
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.create(serializer.validated_data)
            # uid = urlsafe_base64_encode(force_bytes(user.pk))
            # token = default_token_generator.make_token(user)
            # reset_link = reverse('activate_link', kwargs={'uid': uid, 'token': token})
            # reset_url = f'{settings.SITE_DOMAIN}{reset_link}'
            # activation_email(user.email, reset_url)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LoginView(APIView):
    permission_classes = [AllowAny]
    def post(self,request):
        email = request.data.get('email')
        print(email)
        password = request.data.get('password')
        print(password)
        user = authenticate(request, email=email, password=password)
        print(user.username)
        if user is not None:
            if user.is_active:
                login(request, user)
                refresh = RefreshToken.for_user(user)
                data = {"access": str(refresh.access_token),"refresh": str(refresh),  "username": str(user.username),
                        "email": str(user.email)}
                return Response(data, status=status.HTTP_200_OK)
        else:
            return Response({'detail':'Email or Password is incorrect'},status=status.HTTP_400_BAD_REQUEST)


class getdata(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        # Your view logic here
        return Response({"message": "Authenticated successfully"})

