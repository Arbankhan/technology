from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from .views import RegistrationView, LoginView, getdata


urlpatterns = [
    path('register/',RegistrationView.as_view(),name="Register"),
    path('login/',LoginView.as_view(),name='Login'),
    path('data/',getdata.as_view(),name='Login'),
    path('refresh/',TokenRefreshView.as_view(),name='refresh')

]
