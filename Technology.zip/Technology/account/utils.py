def activation_email(email,link):
    pass